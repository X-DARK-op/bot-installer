'use strict';
/**
 * Xtream.js - web terminal for the VPS bot.
 *
 *  - Username is ALWAYS "root".
 *  - Each VPS has its own random password + persistent port (stored in vps.db, table xtream_terminals).
 *  - Login = username(root) + password + port. The port selects the row, the password (scrypt) must
 *    match THAT row, so changing the port never reaches another VPS.
 *  - Origin is plain HTTP on 127.0.0.1; Cloudflare Tunnel provides the public HTTPS hostname.
 *  - Terminal = `lxc exec <container> -- bash` on the local node. No shell, no user-controlled argv.
 *
 * Requires: ws, node-pty, better-sqlite3, @xterm/xterm, @xterm/addon-fit
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const pty = require('node-pty');
const Database = require('better-sqlite3');

// ───────────────────────── config ─────────────────────────
function parseEnvFile(file) {
  const out = {};
  try {
    for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const i = line.indexOf('=');
      if (i < 1) continue;
      const k = line.slice(0, i).trim();
      let v = line.slice(i + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      out[k] = v;
    }
  } catch (_) { /* optional file */ }
  return out;
}
const fileEnv = parseEnvFile(process.env.XTREAM_ENV_FILE || path.join(__dirname, 'xtream.env'));
const cfg = (k, d = '') => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : (fileEnv[k] ?? d));

const PORT = parseInt(cfg('XTREAM_PORT', cfg('CLOUDFLARE_PORT', '8080')), 10);
const BIND = cfg('XTREAM_BIND', '127.0.0.1');
const DB_PATH = cfg('XTREAM_DB', path.join(__dirname, '..', 'vps.db'));
const PORT_START = parseInt(cfg('XTREAM_PORT_START', '30100'), 10);
const PORT_END = parseInt(cfg('XTREAM_PORT_END', '39999'), 10);
const IDLE_MS = Math.max(1, parseInt(cfg('XTREAM_IDLE_MINUTES', '30'), 10)) * 60000;
const MAX_SESSIONS_PER_VPS = 3;
const ENABLED = ['1', 'true', 'yes', 'on'].includes(cfg('XTREAM_ENABLED', 'true').toLowerCase());
const TRUST_PROXY = ['127.0.0.1', '::1', 'localhost'].includes(BIND);
const LXC_BIN = cfg('XTREAM_LXC_BIN', 'lxc');
const CONTAINER_RE = /^[A-Za-z0-9][A-Za-z0-9-]{0,62}$/;

function safeUrl(u) { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch (_) { return ''; } }
const BRAND = {
  name: cfg('XTREAM_HOST_NAME', '').slice(0, 80),
  logo: safeUrl(cfg('XTREAM_LOGO', '')),
  watermark: cfg('XTREAM_WATERMARK', '').slice(0, 160),
};

if (!ENABLED) { console.log('[xtream] XTREAM_ENABLED is false - exiting'); process.exit(0); }
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) { console.error('[xtream] invalid XTREAM_PORT'); process.exit(1); }

// ───────────────────────── database (read-only) ─────────────────────────
let db = null;
function getDb() {
  if (db && db.open) return db;
  db = new Database(DB_PATH, { readonly: true, fileMustExist: true, timeout: 3000 });
  return db;
}
const LOOKUP_SQL = `
  SELECT t.container_name, t.password_hash, t.status AS term_status, t.port,
         v.suspended, n.is_local
    FROM xtream_terminals t
    JOIN vps v   ON v.container_name = t.container_name
    LEFT JOIN nodes n ON n.id = v.node_id
   WHERE t.port = ?`;
function lookupByPort(port) {
  try { return getDb().prepare(LOOKUP_SQL).get(port) || null; }
  catch (e) { console.error('[xtream] database error:', e.code || e.message); try { db && db.close(); } catch (_) {} db = null; return null; }
}

// ───────────────────────── password verification ─────────────────────────
// stored format: scrypt$N$r$p$saltB64$hashB64  (written by bot.py)
const DUMMY_HASH = 'scrypt$16384$8$1$' + Buffer.alloc(16).toString('base64') + '$' + Buffer.alloc(32).toString('base64');
let inflight = 0;
function verifyPassword(password, stored) {
  return new Promise((resolve) => {
    const p = String(stored).split('$');
    if (p.length !== 6 || p[0] !== 'scrypt') return resolve(false);
    const [N, r, pp] = [parseInt(p[1], 10), parseInt(p[2], 10), parseInt(p[3], 10)];
    const salt = Buffer.from(p[4], 'base64'); const want = Buffer.from(p[5], 'base64');
    if (!(N >= 1024 && N <= 1 << 20) || !r || !pp || want.length !== 32) return resolve(false);
    crypto.scrypt(password, salt, 32, { N, r, p: pp, maxmem: 256 * 1024 * 1024 }, (err, dk) => {
      inflight--;
      if (err) return resolve(false);
      resolve(crypto.timingSafeEqual(dk, want));
    });
    inflight++;
  });
}

// ───────────────────────── rate limiting ─────────────────────────
const WINDOW = 10 * 60 * 1000;
const buckets = new Map(); // key -> {n, first, lock}
function rlCheck(key) {
  const b = buckets.get(key); const now = Date.now();
  if (!b) return 0;
  if (b.lock && b.lock > now) return b.lock - now;
  if (now - b.first > WINDOW) buckets.delete(key);
  return 0;
}
function rlFail(key, max, lockMs) {
  const now = Date.now(); let b = buckets.get(key);
  if (!b || now - b.first > WINDOW) b = { n: 0, first: now, lock: 0 };
  b.n++; if (b.n >= max) { b.lock = now + lockMs; b.n = 0; b.first = now; }
  buckets.set(key, b);
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (now - b.first > WINDOW && (!b.lock || b.lock < now)) buckets.delete(k); }, 60000).unref();

function clientIp(req) {
  if (TRUST_PROXY) {
    const h = req.headers['cf-connecting-ip'];
    if (h && /^[0-9a-fA-F:.]{3,45}$/.test(h)) return h;
  }
  return req.socket.remoteAddress || 'unknown';
}

// ───────────────────────── tickets & sessions ─────────────────────────
const tickets = new Map(); // ticket -> {container, ip, exp}
setInterval(() => { const now = Date.now(); for (const [k, v] of tickets) if (v.exp < now) tickets.delete(k); }, 15000).unref();
const sessions = new Map(); // container -> Set(pty)

// ───────────────────────── frontend (embedded) ─────────────────────────
const INDEX_HTML = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Xtream Web Terminal</title>
<link rel="stylesheet" href="/vendor/xterm.css"><link rel="stylesheet" href="/style.css"></head><body>
<main id="login" class="card">
  <img id="logo" alt="" hidden><h2 id="hostname" hidden></h2>
  <h1>Xtream Web Terminal</h1>
  <label for="u">Enter your username</label><input id="u" value="root" autocomplete="username" spellcheck="false">
  <label for="p">Enter your password</label><input id="p" type="password" autocomplete="current-password" spellcheck="false">
  <label for="port">Enter your port</label><input id="port" inputmode="numeric" autocomplete="off" spellcheck="false">
  <button id="go">CONNECT</button><div id="err" role="alert"></div>
  <footer id="wm" hidden></footer>
</main>
<section id="term" hidden><div id="bar"><span id="bartxt"></span><button id="close">Disconnect</button></div><div id="xt"></div></section>
<script src="/vendor/xterm.js"></script><script src="/vendor/addon-fit.js"></script><script src="/app.js"></script></body></html>`;

const STYLE_CSS = `*{box-sizing:border-box}html,body{height:100%;margin:0;background:#0b0f17;color:#e6edf3;font-family:system-ui,Segoe UI,Roboto,sans-serif}
body{display:flex;align-items:center;justify-content:center}.card{width:min(92vw,380px);background:#131a26;border:1px solid #243047;border-radius:14px;padding:26px;box-shadow:0 10px 40px #0008}
h1{font-size:20px;margin:0 0 14px;text-align:center}h2{font-size:14px;margin:6px 0;text-align:center;color:#9fb0c8;font-weight:500}#logo{display:block;max-width:120px;max-height:80px;margin:0 auto 6px}
label{display:block;font-size:13px;color:#9fb0c8;margin:12px 0 5px}input{width:100%;padding:11px 12px;border-radius:8px;border:1px solid #2b3a55;background:#0b0f17;color:#e6edf3;font-size:15px}
input:focus{outline:2px solid #3b82f6;border-color:transparent}button#go{width:100%;margin-top:18px;padding:12px;border:0;border-radius:8px;background:#3b82f6;color:#fff;font-weight:700;letter-spacing:.06em;cursor:pointer}
button#go:disabled{opacity:.6;cursor:wait}#err{min-height:20px;margin-top:10px;color:#ff7b72;font-size:13px;text-align:center}footer{margin-top:14px;text-align:center;font-size:12px;color:#6b7c96}
#term{position:fixed;inset:0;display:flex;flex-direction:column;background:#000}#bar{display:flex;justify-content:space-between;align-items:center;padding:6px 12px;background:#131a26;font-size:13px;color:#9fb0c8}
#bar button{background:#243047;color:#e6edf3;border:0;border-radius:6px;padding:5px 10px;cursor:pointer}#xt{flex:1;padding:6px;min-height:0}`;

const APP_JS = `(function(){
var $=function(i){return document.getElementById(i)};
fetch('/api/config').then(function(r){return r.json()}).then(function(c){
  if(c.name){$('hostname').textContent=c.name;$('hostname').hidden=false;document.title=c.name}
  if(c.logo){$('logo').src=c.logo;$('logo').hidden=false}
  if(c.watermark){$('wm').textContent=c.watermark;$('wm').hidden=false}
}).catch(function(){});
var ws,term,fit;
function fail(m){$('err').textContent=m;$('go').disabled=false}
async function connect(){
  $('err').textContent='';$('go').disabled=true;
  var body={username:$('u').value.trim(),password:$('p').value,port:$('port').value.trim()};
  try{
    var r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var j=await r.json().catch(function(){return{}});
    if(!r.ok) return fail(j.error||'Login failed');
    $('p').value='';open(j.ticket);
  }catch(e){fail('Network error')}
}
function open(ticket){
  $('login').hidden=true;$('term').hidden=false;
  term=new Terminal({cursorBlink:true,fontSize:14,scrollback:5000,theme:{background:'#000000'}});
  fit=new FitAddon.FitAddon();term.loadAddon(fit);term.open($('xt'));fit.fit();
  var proto=location.protocol==='https:'?'wss':'ws';
  ws=new WebSocket(proto+'://'+location.host+'/ws?ticket='+encodeURIComponent(ticket));
  ws.binaryType='arraybuffer';
  ws.onopen=function(){$('bartxt').textContent='Connected';send({type:'resize',cols:term.cols,rows:term.rows});term.focus()};
  ws.onmessage=function(e){term.write(typeof e.data==='string'?e.data:new Uint8Array(e.data))};
  ws.onclose=function(){$('bartxt').textContent='Disconnected';term.write('\\r\\n\\x1b[31m[connection closed]\\x1b[0m\\r\\n')};
  term.onData(function(d){send({type:'input',data:d})});
  window.addEventListener('resize',function(){fit.fit();send({type:'resize',cols:term.cols,rows:term.rows})});
}
function send(m){if(ws&&ws.readyState===1)ws.send(JSON.stringify(m))}
$('go').onclick=connect;
['u','p','port'].forEach(function(i){$(i).addEventListener('keydown',function(e){if(e.key==='Enter')connect()})});
$('close').onclick=function(){if(ws)ws.close();location.reload()};
})();`;

const NM = path.join(__dirname, 'node_modules');
const STATIC = {
  '/': ['text/html; charset=utf-8', INDEX_HTML],
  '/style.css': ['text/css; charset=utf-8', STYLE_CSS],
  '/app.js': ['application/javascript; charset=utf-8', APP_JS],
  '/vendor/xterm.js': ['application/javascript; charset=utf-8', () => fs.readFileSync(path.join(NM, '@xterm/xterm/lib/xterm.js'))],
  '/vendor/xterm.css': ['text/css; charset=utf-8', () => fs.readFileSync(path.join(NM, '@xterm/xterm/css/xterm.css'))],
  '/vendor/addon-fit.js': ['application/javascript; charset=utf-8', () => fs.readFileSync(path.join(NM, '@xterm/addon-fit/lib/addon-fit.js'))],
};
const CSP = "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";

function sendJson(res, code, obj, extra = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body), ...extra });
  res.end(body);
}

// ───────────────────────── HTTP ─────────────────────────
const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const url = new URL(req.url, 'http://x');

  if (req.method === 'GET' && url.pathname === '/healthz') { res.writeHead(200); return res.end('ok'); }
  if (req.method === 'GET' && url.pathname === '/api/config') return sendJson(res, 200, BRAND);
  if (req.method === 'POST' && url.pathname === '/api/login') return handleLogin(req, res);

  if (req.method === 'GET' && STATIC[url.pathname]) {
    try {
      const [type, body] = STATIC[url.pathname];
      const data = typeof body === 'function' ? body() : body;
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': url.pathname === '/' ? 'no-store' : 'public, max-age=300' });
      return res.end(data);
    } catch (_) { res.writeHead(500); return res.end('asset missing'); }
  }
  res.writeHead(404); res.end('Not found');
});

async function handleLogin(req, res) {
  const ip = clientIp(req);
  const wait = rlCheck('ip:' + ip);
  if (wait) return sendJson(res, 429, { error: 'Too many attempts. Try again later.' }, { 'Retry-After': Math.ceil(wait / 1000) });
  if (inflight > 8) return sendJson(res, 503, { error: 'Busy, try again shortly.' });

  let raw = '';
  try {
    await new Promise((ok, no) => {
      req.on('data', (c) => { raw += c; if (raw.length > 2048) { no(new Error('big')); req.destroy(); } });
      req.on('end', ok); req.on('error', no);
    });
  } catch (_) { return; }
  let b; try { b = JSON.parse(raw); } catch (_) { return sendJson(res, 400, { error: 'Bad request' }); }
  const username = typeof b.username === 'string' ? b.username : '';
  const password = typeof b.password === 'string' ? b.password : '';
  const portStr = String(b.port ?? '').trim();
  const portNum = /^\d{1,5}$/.test(portStr) ? parseInt(portStr, 10) : NaN;

  const pairKey = 'pair:' + ip + ':' + portStr, portKey = 'port:' + portStr;
  const w2 = Math.max(rlCheck(pairKey), rlCheck(portKey));
  if (w2) return sendJson(res, 429, { error: 'Too many attempts. Try again later.' }, { 'Retry-After': Math.ceil(w2 / 1000) });

  const inRange = Number.isInteger(portNum) && portNum >= PORT_START && portNum <= PORT_END;
  const row = inRange ? lookupByPort(portNum) : null;
  // Always burn one scrypt so timing does not reveal whether the port exists.
  const pwOk = await verifyPassword(password, row ? row.password_hash : DUMMY_HASH);
  const good = username === 'root' && pwOk && row && row.term_status === 'active' && !row.suspended
             && CONTAINER_RE.test(row.container_name);

  if (!good) {
    rlFail('ip:' + ip, 10, 15 * 60000); rlFail(pairKey, 5, 10 * 60000); rlFail(portKey, 40, 5 * 60000);
    console.log(`[xtream] failed login from ${ip}`); // never log password/port/user input
    return sendJson(res, 401, { error: 'Invalid credentials' });
  }
  if (!row.is_local) return sendJson(res, 501, { error: 'Web terminal is only available for VPS on the local node.' });

  const ticket = crypto.randomBytes(32).toString('hex');
  tickets.set(ticket, { container: row.container_name, ip, exp: Date.now() + 30000 });
  console.log(`[xtream] login ok from ${ip}`);
  return sendJson(res, 200, { ticket });
}

// ───────────────────────── WebSocket terminal ─────────────────────────
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://x');
  const origin = req.headers.origin;
  let originOk = false;
  try { originOk = !!origin && new URL(origin).host === req.headers.host; } catch (_) {}
  if (url.pathname !== '/ws' || !originOk) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); return socket.destroy(); }
  const t = tickets.get(url.searchParams.get('ticket') || '');
  tickets.delete(url.searchParams.get('ticket') || ''); // single use
  if (!t || t.exp < Date.now() || t.ip !== clientIp(req)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy(); }
  wss.handleUpgrade(req, socket, head, (ws) => startSession(ws, t.container));
});

function startSession(ws, container) {
  // re-validate against the DB at connect time (deleted / suspended VPS)
  const row = (() => { try { return getDb().prepare('SELECT v.suspended FROM vps v WHERE v.container_name = ?').get(container); } catch (_) { return null; } })();
  if (!row || row.suspended || !CONTAINER_RE.test(container)) { ws.send('\r\nVPS unavailable.\r\n'); return ws.close(); }
  const set = sessions.get(container) || new Set(); sessions.set(container, set);
  if (set.size >= MAX_SESSIONS_PER_VPS) { ws.send('\r\nToo many open terminals for this VPS.\r\n'); return ws.close(); }

  const shell = 'command -v bash >/dev/null 2>&1 && exec bash -l || exec sh -l';
  let term;
  try {
    term = pty.spawn(LXC_BIN, ['exec', container, '--env', 'TERM=xterm-256color', '--env', 'HOME=/root', '--cwd', '/root', '--', 'sh', '-c', shell], {
      name: 'xterm-256color', cols: 80, rows: 24,
      env: { PATH: process.env.PATH, HOME: process.env.HOME || '/tmp', LANG: 'C.UTF-8' },
    });
  } catch (e) { ws.send('\r\nCould not open terminal.\r\n'); console.error('[xtream] spawn failed:', e.message); return ws.close(); }
  set.add(term);

  let idle = setTimeout(() => { try { ws.send('\r\n[idle timeout]\r\n'); } catch (_) {} ws.close(); }, IDLE_MS);
  const touch = () => { clearTimeout(idle); idle = setTimeout(() => { try { ws.send('\r\n[idle timeout]\r\n'); } catch (_) {} ws.close(); }, IDLE_MS); };

  term.onData((d) => { if (ws.readyState === 1) ws.send(d); });
  term.onExit(() => { clearTimeout(idle); set.delete(term); if (!set.size) sessions.delete(container); try { ws.close(); } catch (_) {} });
  ws.on('message', (m) => {
    touch();
    let msg; try { msg = JSON.parse(m.toString()); } catch (_) { return; }
    if (msg.type === 'input' && typeof msg.data === 'string' && msg.data.length <= 16384) term.write(msg.data);
    else if (msg.type === 'resize') {
      const c = Math.min(500, Math.max(1, msg.cols | 0)), r = Math.min(200, Math.max(1, msg.rows | 0));
      try { term.resize(c, r); } catch (_) {}
    }
  });
  ws.on('close', () => { clearTimeout(idle); try { term.kill(); } catch (_) {} });
  ws.on('error', () => { try { term.kill(); } catch (_) {} });
}

// ───────────────────────── boot / shutdown ─────────────────────────
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`[xtream] port ${PORT} is already in use - change XTREAM_PORT (and CLOUDFLARE_PORT) in .env`);
  else console.error('[xtream] server error:', e.message);
  process.exit(1);
});
server.listen(PORT, BIND, () => console.log(`[xtream] listening on http://${BIND}:${PORT} (origin; public access via Cloudflare Tunnel)`));

function shutdown() {
  for (const set of sessions.values()) for (const t of set) { try { t.kill(); } catch (_) {} }
  server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
