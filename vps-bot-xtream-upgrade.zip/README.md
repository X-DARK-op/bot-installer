# Existing VPS Discord Bot + Xtream Installer

This package keeps the existing Python bot architecture and adds the missing VPS installer/deployment layer.

## Files

- `bot.py` — existing bot, copied without feature removal; only the unsafe Discord-token error log was removed.
- `xtream.js` — existing Xtream terminal implementation.
- `install.sh` — idempotent Ubuntu/Debian installer.
- `.env.example` — existing environment variables plus Xtream/Cloudflare/MOTD/Tailscale settings.
- `package.json` — Xtream Node dependencies.
- `xtream.service`, `cloudflared-vps-bot.service`, `vps-bot.service` — systemd templates.
- `requirements.txt` — existing Python dependencies.

## One-line installation

After publishing these files in a GitHub repository:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/USERNAME/REPOSITORY/main/install.sh)
```

The installer additionally asks for the raw GitHub base URL containing the existing `bot.py` and `requirements.txt`, because a piped `curl | bash` script cannot reliably discover its own GitHub repository URL.

## Cloudflare token permissions

The API token must be able to manage the selected Cloudflare Tunnel and DNS record. Cloudflare documents Tunnel Edit and DNS Edit as the required permissions for this workflow. The installer also needs enough account visibility to resolve the account ID automatically; otherwise set `CLOUDFLARE_ACCOUNT_ID` in `.env` and rerun. citeturn0search1turn0search13

The installer uses `cloudflared tunnel run --token-file ...`, so the connector token is stored in a root-only file instead of being placed in the process command line. Current cloudflared supports `--token-file` for remotely managed tunnels. citeturn1search6turn1search4

## Important architecture note

The Xtream "port" assigned to each VPS is a persistent credential selector stored in `xtream_terminals`; it is not a separate listening socket. Xtream itself listens on one local HTTP port, and Cloudflare publishes the single hostname. The existing `xtream.js` verifies username `root`, password hash, and the submitted port against the same database row before issuing a single-use terminal ticket. fileciteturn0file0L71-L80 fileciteturn0file0L260-L275

The existing bot already creates persistent Xtream mappings, allocates a free port, encrypts the credential for DM retrieval, and keeps username `root`. fileciteturn0file1L619-L658

## Verification

After installation:

```bash
systemctl status xtream.service --no-pager
systemctl status cloudflared-vps-bot.service --no-pager
systemctl status vps-bot.service --no-pager
curl -fsS http://127.0.0.1:8080/healthz
```

Use the configured Xtream port in the last command if you chose another port.

Never paste `.env`, `/etc/cloudflared/tunnel-token`, or Discord terminal credentials into Discord/public logs.
